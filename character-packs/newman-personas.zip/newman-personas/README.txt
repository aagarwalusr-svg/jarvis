Fictional childhood Newman character pack

Julian: story age 10, compact basketball competitor.
Jaden: story age 7, playful younger sister.
Ages, personality, clothing, dialogue, and story details are creative choices, not documented biography.

Contains reusable JSON persona definitions, AI/visual prompts, original SVG expression drafts, and PNG previews. These illustrations are concept drafts, not photorealistic likenesses or generated video clips.

For Claude, use the character system prompt as fictional roleplay context. For the coded interactive studio, open the full JARVIS project and visit /personas. Live dialogue preview requires your configured provider API key. No credentials or real-person voice recordings are included.
